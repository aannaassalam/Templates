import normalize from '../../utils/helpers/dimen';

export const globalConstant = {
  marginHorizontal: normalize(20),
  marginVertical: normalize(20),
  marginRight: normalize(20),
  marginLeft: normalize(20),
};
