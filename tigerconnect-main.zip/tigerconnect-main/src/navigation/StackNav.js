import {
  DarkTheme,
  DefaultTheme,
  NavigationContainer,
} from '@react-navigation/native';
import {BackHandler} from 'react-native';

import {
  createStackNavigator,
  TransitionSpecs,
  HeaderStyleInterpolators,
} from '@react-navigation/stack';
import * as React from 'react';
import SplashScreen from '../screen/splashScreen/SplashScreen';
import DrawerNavigation from '../screen/Auth/DrawerNavigation'
import SignUp from '../screen/Auth/Signup';
const StackNav = ({props, navigation}) => {
  const Stack = createStackNavigator();

  const mytheme = {
    ...DarkTheme,
    colors: {
      ...DarkTheme.colors,
    },
  };
  const MyTransition = {
    // gestureDirection: "vertical",
    transitionSpec: {
      open: TransitionSpecs.TransitionIOSSpec,
      close: TransitionSpecs.TransitionIOSSpec,
    },
    headerStyleInterpolator: HeaderStyleInterpolators.forFade,
    cardStyleInterpolator: ({current, next, layouts}) => {
      return {
        cardStyle: {
          transform: [
            {
              translateX: current.progress.interpolate({
                inputRange: [0, 1],
                outputRange: [layouts.screen.width, 1],
              }),
            },
          ],
        },
        overlayStyle: {
          opacity: current.progress.interpolate({
            inputRange: [0, 0.1],
            outputRange: [0, 0.1],
          }),
        },
      };
    },
  };

  const Screens = {
    SplashScreen: SplashScreen,
    DrawerNavigation:DrawerNavigation,
    SignUp:SignUp
  };
  
  return (
    <NavigationContainer
      theme={mytheme}
      //    ref={navigationRef}
    >
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
          ...MyTransition,
          animationEnabled: true,
        }}
        initialRouteName="Splash">
        {Object.entries({
          ...Screens,
        }).map(([name, component]) => {
          return <Stack.Screen name={name} component={component} key={name} />;
        })}
      </Stack.Navigator>
    </NavigationContainer>
  );
};
export default StackNav;
