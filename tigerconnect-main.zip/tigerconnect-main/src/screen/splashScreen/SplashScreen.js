import {StyleSheet, Text, View, ImageBackground} from 'react-native';
import React from 'react';
import {Icons} from '../../themes/ImagePath';
import {useNavigation} from '@react-navigation/native';

const SplashScreen = () => {
  const navigation = useNavigation();

  setTimeout(() => {
    navigation?.navigate('DrawerNavigation');
  }, 1000);
  return (
    <>
      <ImageBackground
        source={Icons.Splash}
        style={{flex: 1, width: '100%', height: '103%'}}
        resizeMode="cover"
      />
    </>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({});
