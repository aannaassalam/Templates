import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const TigerMatch = () => {
  return (
    <View>
      <Text>TigerMatch</Text>
    </View>
  )
}

export default TigerMatch

const styles = StyleSheet.create({})