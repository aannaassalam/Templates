import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const PasswordChangeSuccess = () => {
  return (
    <View>
      <Text>PasswordChangeSuccess</Text>
    </View>
  )
}

export default PasswordChangeSuccess

const styles = StyleSheet.create({})