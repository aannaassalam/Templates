import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Approval = () => {
  return (
    <View>
      <Text>Approval</Text>
    </View>
  )
}

export default Approval

const styles = StyleSheet.create({})