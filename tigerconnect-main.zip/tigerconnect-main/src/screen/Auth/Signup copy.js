import React, {useState} from 'react';
import {
  Dimensions,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Fonts, Icons} from '../../themes/ImagePath';
import normalize from '../../utils/helpers/dimen';
import MyStatusBar from '../../utils/helpers/MyStatusBar';
import TextInputItem from '../../components/TextInput';
import { Colors } from '../../themes/Colors';


let status = '';
import Loader from '../../utils/helpers/Loader';
import BtnGroup from '../../components/BtnGroup';
export default function SignUp(props) {
  const [email, setemail] = useState('');
  const [showhide, setshowhide] = useState(true);
  const [password, setpassword] = useState('');
  const [rememberbtn, setrememberbtn] = useState(false);
  const [phone, setphone] = useState('');
  const [username, setusername] = useState('');
  const [confirmpassword, setconfirmpassword] = useState('');
  const [showhide1, setshowhide1] = useState(true);
  const [confirmpasswordfocus, setconfirmpasswordfocus] = useState(false);
  const height1 = Dimensions.get('window').height;
 
  return (
    <>
      <MyStatusBar />
      
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        // keyboardVerticalOffset={Platform.OS === "ios" ? 150 : 0}
        // enabled
        style={{flex: 1}}>
        <SafeAreaView style={{flex: 1, backgroundColor: Colors.background}}>
          <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
            <ImageBackground
              style={{
                width: '100%',
                height: normalize(180),
                marginTop:
                  Platform.OS == 'android' ? StatusBar.currentHeight : 0,
              }}
              resizeMode="stretch"
              source={Icons.HeaderBackground}>
              {/* <TouchableOpacity onPress={()=>props?.navigation?.goBack()} 
               style={{position:'absolute',alignSelf:'flex-start',left:'2.5%',top:normalize(45)}}>
                        <Image source={Icons.backarrow} style={{width:normalize(25),height:normalize(25)}}/>
                    </TouchableOpacity> */}
            </ImageBackground>
            <View
              //   keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
              // behavior={Platform.OS === 'ios' ? 'padding' : undefined}
              style={{
                width: '95%',
                minHeight: height1 - normalize(180),
                backgroundColor: Colors.white,
                // position: 'absolute',
                alignSelf: 'center',
                justifyContent: 'center',
                alignItems: 'center',
                //  bottom: normalize(20),
                borderRadius: normalize(10),
                padding: normalize(8),
                marginTop: -normalize(60),
                marginBottom: normalize(20),
                paddingBottom: normalize(40),
              }}>
              <Image source={Icons.Rlogo} style={styles.headerimage} />

              <Text style={styles.head1sttext}>
                Sign <Text style={{color: Colors.button}}>Up</Text>
              </Text>
              <Text style={styles.head2ndtext}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Phasellus vestibulum.
              </Text>
              <TextInputItem
                toptext={'Phone Number'}
                placeholder={'Enter Your Phone Number'}
                value={phone}
                onChangeText={val => setphone(val)}
                // onFocus={() => setphonenumberfocus(true)}
                // onBlur={() => setphonenumberfocus(false)}
                // focus={phonenumberfocus}
                marginTop={normalize(40)}
                maxLength={16}
                keyboardType={'phone-pad'}
              />
              <TextInputItem
                toptext={'User Name*'}
                placeholder={'Enter User Name'}
                value={username}
                onChangeText={val => setusername(val)}
                // onFocus={() => setusernamefocus(true)}
                // onBlur={() => setusernamefocus(false)}
                // focus={usernamefocus}
              />
              <View style={{width: '100%', marginTop: normalize(8)}}>
                <Text
                  style={{
                    color: '#A0A0A0',
                    fontFamily: Fonts.Nunito_MediumItalic,
                    fontSize: normalize(11),
                    textAlign: 'left',
                  }}>
                  User name can be changed.
                </Text>
              </View>
              <TextInputItem
                toptext={'Email Address*'}
                placeholder={'Enter Your Email Address'}
                value={email}
                onChangeText={val => setemail(val)}
                // onFocus={() => setemailfocus(true)}
                // onBlur={() => setemailfocus(false)}
                // focus={emailfocus}
              />
              <TextInput style={{width: 0, height: 0}} editable={false} />
              <TextInputItem
                toptext={'Password*'}
                placeholder={'**********'}
                value={password}
                onChangeText={val => setpassword(val)}
                isSecure={showhide}
                isrightimage={true}
                rightimagepress={() => setshowhide(!showhide)}
                showhide={showhide}
                // onFocus={() => setpasswordfocus(true)}
                // onBlur={() => setpasswordfocus(false)}
                // focus={passwordfocus}
              />
              <TextInput style={{width: 0, height: 0}} editable={false} />
              <TextInputItem
                toptext={'Confirm Password*'}
                placeholder={'**********'}
                value={confirmpassword}
                onChangeText={val => setconfirmpassword(val)}
                isSecure={showhide1}
                isrightimage={true}
                rightimagepress={() => setshowhide1(!showhide1)}
                showhide={showhide1}
                // onFocus={() => setconfirmpasswordfocus(true)}
                // onBlur={() => setconfirmpasswordfocus(false)}
                focus={confirmpasswordfocus}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  width: '100%',
                  marginTop: normalize(20),
                }}></View>
              <BtnGroup
                onPress={() => signupfunction()}
                marginTop={normalize(15)}
                title={'Register'}
              />
              <View style={{marginTop: normalize(20), flexDirection: 'row'}}>
                <Text style={styles.txtdonthaveaccount}>
                  Already have any account?{' '}
                </Text>
                <TouchableOpacity
                  onPress={() => props?.navigation?.navigate('Login')}>
                  <Text
                    style={[styles.txtdonthaveaccount,]}>
                    {' '}
                    Login
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </>
  );
}

const styles = StyleSheet.create({
  headerimage: {
    width: normalize(60),
    height: normalize(70),
    resizeMode: 'stretch',
    position: 'absolute',
    right: normalize(-5),
    top: 0,
  },
  head1sttext: {
    fontSize: normalize(18),
    fontFamily: Fonts.Nunito_Medium,
    color: Colors.black,
    marginTop: normalize(35),
  },
  head2ndtext: {
    color: Colors.textcolor,
    fontFamily: Fonts.Nunito_Regular,
    fontSize: normalize(12),
    width: '80%',
    textAlign: 'center',
    marginTop: normalize(10),
  },
  txtdonthaveaccount: {
    fontSize: normalize(13),
    fontFamily: Fonts.Nunito_Regular,
    color: Colors.textblackcolor,
    fontWeight: '600',
  },
});
