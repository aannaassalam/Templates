import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const OtpVerify = () => {
  return (
    <View>
      <Text>OtpVerify</Text>
    </View>
  )
}

export default OtpVerify

const styles = StyleSheet.create({})