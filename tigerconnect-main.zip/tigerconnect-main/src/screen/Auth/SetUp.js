import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SetUp = () => {
  return (
    <View>
      <Text>SetUp</Text>
    </View>
  )
}

export default SetUp

const styles = StyleSheet.create({})