import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SignIn = () => {
  return (
    <View>
      <Text>SignIn</Text>
    </View>
  )
}

export default SignIn

const styles = StyleSheet.create({})