import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ChangePassword = () => {
  return (
    <View>
      <Text>ChangePassword</Text>
    </View>
  )
}

export default ChangePassword

const styles = StyleSheet.create({})