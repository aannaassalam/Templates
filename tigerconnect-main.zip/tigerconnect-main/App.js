import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';
import StackNav from './src/navigation/StackNav';

export default function App() {
  return <StackNav />;
}
