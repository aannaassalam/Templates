/* eslint-disable no-console */



import { useAppSelector } from "./useAppSelector";
import { useAppDispatch } from "./useAppDispatch";
import { Cookies } from "react-cookie";
import { logout, setLoginData } from "../redux-toolkit/slices/userSlice";
import { useQuery } from "react-query";
import { GetProfileDetails } from "../api/functions/user.api";

const useUser = () => {
  const cookie = new Cookies();
  const token = cookie.get("career_token");
  const dispatch = useAppDispatch();
  const { userData } = useAppSelector((s) => s.userSlice);

  const profileDetails = useQuery("userdetails", GetProfileDetails, {
    enabled: !!token && userData === null,
    onSuccess(data) {
      if (data?.data?.status === 401) {
        dispatch(logout());
      } else {
        dispatch(setLoginData(data?.data?.data));
      }
    },
    onError() {
      dispatch(logout());
    },
  });


  return { ...profileDetails };
};

export default useUser;
