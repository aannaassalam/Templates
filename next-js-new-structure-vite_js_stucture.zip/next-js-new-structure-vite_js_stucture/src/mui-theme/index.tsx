import { useMemo } from "react";
// material-ui
import CssBaseline from "@mui/material/CssBaseline";
import StyledEngineProvider from "@mui/material/StyledEngineProvider";
import { ThemeProvider, createTheme } from "@mui/material/styles";

// project import
import shadows from "./shadows";
import Typography from "./typography";
// import componentsOverride from "./overrides";

// ==============================|| DEFAULT THEME - MAIN  ||============================== //
export default function ThemeCustomization({ children }:{
  children:React.ReactNode
}) {
  // const theme = Palette();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const themeTypography = Typography(`'Poppins', sans-serif`);


  const themeOptions = useMemo(
    () => ({
      shape: { borderRadius: 6 },
      typography: themeTypography,
      shadows: shadows()
    }),
    []
  );

  const themes = createTheme(themeOptions);
  // themes.components = componentsOverride(themes);

  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={themes}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </StyledEngineProvider>
  );
}
