/* eslint-disable no-undef */
import React from "react";
import { Backdrop, Box, CircularProgress } from "@mui/material";
import Footer from "../Footer/Footer";
import useOnlineStatus from "../../hooks/useDetectOnline";
import Header from "../Header/Header";


interface wrapperProps {
  children: JSX.Element | JSX.Element[];
}

const Wrapper = (props: wrapperProps) => {
  const { children } = props;

  const [open, setOpen] = React.useState(false);
  const handleClose = () => {
    setOpen(false);
  };
  // const handleOpen = () => {
  //   setOpen(true);
  // };



 



  useOnlineStatus();

  
  return (
    <>
     
     
      <Header />

      <Box className="body_content">{children}</Box>

      <Footer />

      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={open}
        onClick={handleClose}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
};

export default Wrapper;
