
import { OptionsObject, SnackbarMessage, useSnackbar } from "notistack";
import { useCallback, useEffect } from "react";
import eventEmitter from "../../services/event.emitter";
import events from "../../json/events/events";


export default function EventListeners() {
    const { enqueueSnackbar } = useSnackbar();
    const showNotifications = useCallback(
      (data: { message: SnackbarMessage; options?: OptionsObject }) => {
        enqueueSnackbar(data.message, data.options);
      },
      []
    );
    useEffect(() => {
      eventEmitter.on(events.showNotification, showNotifications);
      return () => {
        eventEmitter.off(events.showNotification, showNotifications);
      };
    }, []);
  
    

  
  

   
  

  
    return null;
  }
  