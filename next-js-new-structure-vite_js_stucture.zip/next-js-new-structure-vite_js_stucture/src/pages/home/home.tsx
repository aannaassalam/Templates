import { Box, Button } from '@mui/material'

const Home = () => {
  return (
    <Box>
      <Button>Test</Button>
    </Box>
  )
}

export default Home