

import {
  RouterProvider,
} from "react-router-dom";
import { store } from "./redux-toolkit/store/store";
import { Provider } from "react-redux";
import {  QueryClient, QueryClientProvider } from "react-query";
import ToastifyProvider from "./ui/toastify/ToastifyProvider";
import EventListeners from "./components/EventListener/EventListener";
import MuiTheme from "./mui-theme";
import { router } from "./routes/routes";



export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      refetchOnReconnect: true,
      retry: 1,

      // networkMode: 'offlineFirst'
    },

  },
});

function App() {


  return (
    <Provider store={store}>
      
        <QueryClientProvider client={queryClient}>
     
            <ToastifyProvider>
              <MuiTheme>
                <EventListeners />



                <RouterProvider router={router} />
              </MuiTheme>
            </ToastifyProvider>
          

          {/* {process.env.NODE_ENV === "development" && (
          <ReactQueryDevtools initialIsOpen={false} />
        )} */}
        </QueryClientProvider>
    

    </Provider>

    
  )
}

export default App
