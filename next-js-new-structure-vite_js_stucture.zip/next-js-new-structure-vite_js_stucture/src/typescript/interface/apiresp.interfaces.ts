
import { BaseApiResponse, UserData } from "./common.interface";

export interface IgetSignUpQuery extends BaseApiResponse{
   data: UserData
  }
  