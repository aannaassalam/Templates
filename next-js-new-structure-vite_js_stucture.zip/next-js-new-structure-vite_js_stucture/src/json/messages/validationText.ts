export default {
  success: {},
  error: {
    enter_email: "Enter email",
    email_format: "Email format is not correct",
    enter_password: "Enter password",
    phone: "Enter phone",
    username: "Enter username",
    fullName: "Enter Full Name",
    first_name: "Enter First Name",
    last_name: "Enter Last Name"
  },
  warn: {},
  info: {}
};
