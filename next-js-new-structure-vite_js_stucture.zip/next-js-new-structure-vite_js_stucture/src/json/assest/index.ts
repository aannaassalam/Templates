export default {
  notfound: "/assets/images/404.svg",
  logo: "/vercel.svg",
  logo_img:"/assets/images/logo_img.png"
};
