
import {  createSlice } from "@reduxjs/toolkit";
import { destroyCookie } from "nookies";
import { userSliceData } from "../interfaces/interfaces";
import { UserData } from "../../typescript/interface/common.interface";

const initialState: userSliceData = {
  isLoggedIn: false,
  userData: null,
};



export const userSlice = createSlice({
  name: "userSlice",
  // `createSlice` will infer the state type from the `initialState` argument
  initialState,
  reducers: {
    setLoginData: (state, { payload }: { payload: UserData }) => {
      // state.email
      state.userData = payload;
      state.isLoggedIn = true;
    },
    checkLoggedInServer: (state, { payload }) => {
      state.isLoggedIn = payload?.hasToken;
      state.userData = payload?.user;
    },
    logout: (state) => {
      state.isLoggedIn = false;
      state.userData = null;
      // cookie.remove("privy_token");
      // cookie.remove("user");

      destroyCookie(null, "user", { path: "/" });
      destroyCookie(null, "career_token", { path: "/" });

      window.location.href = "/login";
    },
  },
  extraReducers: {},
});

export const { setLoginData, checkLoggedInServer, logout } = userSlice.actions;

export default userSlice.reducer;
