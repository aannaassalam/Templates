import globalSlice from "./global.slice";
import userSlice from "./userSlice";

const rootReducer = {
  userSlice,
  globalSlice
};

export default rootReducer;
