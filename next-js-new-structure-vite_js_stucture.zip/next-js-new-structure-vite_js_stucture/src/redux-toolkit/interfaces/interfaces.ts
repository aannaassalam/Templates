import { UserData } from "../../typescript/interface/common.interface";


export interface userSliceData {
  isLoggedIn: boolean;
  userData: UserData | null;
}

export interface registrationData {}



export interface globalStateInterface {
  counter: number;
}
