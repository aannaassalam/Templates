import { InferSchemaType, Model, Schema, model } from "mongoose";
import bcrypt from "bcrypt";
import AppError from "../AppError";

type schemaType = InferSchemaType<typeof userSchema>;

const userSchema = new Schema(
  {
    first_name: {
      type: String,
      required: [true, "Please Enter First Name!"],
    },
    last_name: {
      type: String,
      required: [true, "Please Enter Last Name!"],
    },
    email: {
      type: String,
      required: [true, "Please Enter Email!"],
      set: (value: string) => value.toLowerCase(),
    },
    password: {
      type: String,
      required: [true, "Please Enter Password!"],
    },
  },
  {
    statics: {
      async login(email, password) {
        const user = await this.findOne({ email });
        if (user) {
          const matched = await bcrypt.compare(
            password.toString(),
            user.password
          );
          if (matched) return user;
          throw new AppError(0, "Incorrect Password", 400);
        }
        throw new AppError(0, "User doesn't exists", 400);
      },
    },
  }
);

userSchema.pre<schemaType>("save", async function (next) {
  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password.toString(), salt);
  next();
});

export default model("user", userSchema);
