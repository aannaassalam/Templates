import { NextFunction, Request, Response } from "express";

type tryCatchController = (req: Request, res: Response) => any;

const ControllerWrapper =
  (controller: tryCatchController) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await controller(req, res);
    } catch (error) {
      return next(error);
    }
  };

export default ControllerWrapper;
