import { NextFunction, Request, Response } from "express";
import User from "../Models/user";
import jwt from "jsonwebtoken";
import config from "../config";
import { Types } from "mongoose";
import Joi from "joi";
import AppError from "../AppError";

export type GeneralAPIType = (req: Request, res: Response) => void;

const createToken = (user_id: Types.ObjectId) => {
  return jwt.sign({ _id: user_id }, config.auth.jwtSecret, {
    expiresIn: config.auth.jwt_expiresin,
  });
};

export const getUserProfile: GeneralAPIType = async (req, res) => {};

export const login: GeneralAPIType = async (req, res) => {
  const { email, password } = req.body;
  console.log(email);

  const user = await User.login(email, password);
  const new_user = await User.findById(user._id, { password: 0 });
  res.json({
    token: createToken(user._id),
    user: new_user,
  });
};

export const register: GeneralAPIType = async (req, res) => {
  const schema = Joi.object({
    first_name: Joi.string().trim().required(),
    // .message("First Name is required!"),
    last_name: Joi.string().trim().required(),
    email: Joi.string().email().trim().required(),
    password: Joi.string()
      .min(8)
      // .message("Password should be atleast 8 characters")
      .trim()
      .required(),
    // .message("Password is required!"),
  });

  const { error, value } = schema.validate(req.body);
  if (error) throw error;

  const user = await User.create(value);
  const new_user = await User.findById(user._id, { password: 0 });
  res.json({
    token: createToken(user._id),
    user: new_user,
  });
};
