import { Router } from "express";
import ControllerWrapper from "../utils/ControllerWrapper";
import { getUserProfile, register, login } from "../Controllers/user";
import { checkUser } from "../middleware/user";

const router = Router();

router.get("/", (req, res) => res.send("jii"));
router.get("/profile", checkUser, ControllerWrapper(getUserProfile));
router.post("/login", ControllerWrapper(login));
router.post("/register", ControllerWrapper(register));

export default router;
