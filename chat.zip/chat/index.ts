import dotenv from "dotenv";
import express from "express";
import { createServer } from "http";
import mongoose from "mongoose";
import { Socket, Server as SocketIOServer } from "socket.io";
import ErrorHandler from "./middleware/errorHandler";
import { getUserSocket } from "./middleware/user";
import user from "./Routes/user";
import config from "./config";
import jwt, { VerifyCallback } from "jsonwebtoken";
import User from "./Models/user";
import { v4 as uuidv4 } from "uuid";
import cors from "cors";

interface JWTInterface {
  _id: string;
}

interface enhanceSocket extends Socket {
  user?: any;
}

dotenv.config();

const PORT = process.env.PORT || 5000;
const corsOption = {
  origin: "*",
};

const socket_users: { [key: string]: string } = {};
const rooms: { [key: string]: { _id: string; role: string }[] } = {};

const app = express();
const server = createServer(app);
const io = new SocketIOServer(server, {
  cors: corsOption,
});

app.use(cors(corsOption));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/user", user);

app.use(ErrorHandler);

io.use(async (socket: enhanceSocket, next) => {
  const { token } = socket.handshake.headers;
  jwt.verify(
    token as string,
    config.auth.jwtSecret,
    async function (err, decoded) {
      if (err) {
        socket.disconnect(true);
        next();
      }
      const user = await User.findById((decoded as JWTInterface)?._id, {
        password: 0,
        _v: 0,
      });
      if (!user) {
        socket.disconnect(true);
      }
      socket.user = { ...user, _id: user?._id.toString() };
      next();
    }
  );
});

io.on("connection", (socket: enhanceSocket) => {
  if (socket.user) {
    socket_users[socket.user._id.toString()] = socket.id;
  }

  socket.on("room:create", () => {
    const room_id = uuidv4();
    socket.join(room_id);
    rooms[room_id] = [
      ...(rooms[room_id] || []),
      { _id: socket.user._id, role: "admin" },
    ];
    socket.emit("room:created", room_id);
    io.emit("room:update", rooms);
  });

  socket.on("get:rooms", () => {
    socket.emit("rooms:data", rooms);
  });

  socket.on("room:join", (room_id) => {
    if (!rooms[room_id]?.find((_user) => _user._id === socket.user._id)) {
      console.log("socket");
      socket.join(room_id);
      rooms[room_id] = [
        ...(rooms[room_id] || []),
        { _id: socket.user._id, role: "viewer" },
      ];
    }
    console.log(rooms);
    io.emit("room:update", rooms);
  });

  socket.on("room:leave", (room_id) => {
    if (rooms[room_id]) {
      if (
        rooms[room_id].find((_user) => _user._id === socket.user._id)?.role ===
        "admin"
      ) {
        socket.to(room_id).emit("room:destroyed", "The room is destroyed!");
        delete rooms[room_id];
      } else {
        rooms[room_id] = rooms[room_id].filter(
          (_user) => _user._id !== socket.user._id
        );
      }
    }
    io.emit("room:update", rooms);
  });

  socket.on("offer", (offer, room_id) => {
    console.log(offer, room_id);
    socket.to(room_id).emit("offer", offer);
  });

  socket.on("answer", (answer, room_id) => {
    socket.to(room_id).emit("answer", answer);
  });

  socket.on("disconnect", (daa) => {
    delete socket_users[socket?.user?._id];
    Object.entries(rooms).forEach((_data) => {
      rooms[_data[0]] = _data[1].filter(
        (_item) => _item._id !== socket?.user?._id
      );
    });
  });
});

mongoose
  .connect(process.env.DB_URL!, {
    dbName: "chat",
  })
  .then(() => {
    server.listen(PORT, () => {
      console.log(`Server is Running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.log(err);
  });
