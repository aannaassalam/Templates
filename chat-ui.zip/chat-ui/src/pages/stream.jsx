import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import socketInstance from "../socketInstance";

export default function Stream() {
  const [searchParams] = useSearchParams();
  const socket = socketInstance(localStorage.getItem("token"));
  const [lol, setLol] = useState(false);

  const { RTCPeerConnection, RTCSessionDescription } = window;

  const peerConnection = new RTCPeerConnection({
    iceServers: [
      {
        urls: ["stun:stun.stunprotocol.org"],
      },
    ],
  });

  const startOffer = async () => {
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(new RTCSessionDescription(offer));
    socket.emit("offer", offer, searchParams.get("watch"));
  };

  const setRemoteOffer = async (offer) => {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await peerConnection.createAnswer();
    console.log(offer);
    await peerConnection.setLocalDescription(new RTCSessionDescription(answer));
    socket.emit("answer", answer, searchParams.get("watch"));
    console.log(answer, "answer");
  };

  const setAnswer = async (answer) => {
    await peerConnection.setRemoteDescription(
      new RTCSessionDescription(answer)
    );
    console.log("rev");
  };

  socket.emit("room:join", searchParams.get("watch"));

  useEffect(() => {
    if (searchParams.get("admin")) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          const localVideo = document.getElementById("local-video");
          if (localVideo) {
            localVideo.srcObject = stream;
          }
          //   startOffer();
          socket.on("offer", setRemoteOffer);
          socket.on("answer", setAnswer);
        })
        .catch((error) => {
          console.warn(error.message);
        });
    } else {
      peerConnection.ontrack = ({ streams: [stream] }) => {
        const remoteVideo = document.getElementById("local-video");
        if (remoteVideo) {
          remoteVideo.srcObject = stream;
          setLol(true);
        }
      };
      startOffer();
      socket.on("offer", setRemoteOffer);
      socket.on("answer", setAnswer);
    }

    return () => {
      socket.removeEventListener("offer", setRemoteOffer);
      socket.removeEventListener("answer", setAnswer);
    };
  }, []);

  return (
    <div>
      <h3>{searchParams.get("watch")}</h3>
      {/* {searchParams.get("admin") ? ( */}
      <video autoPlay className="local-video" id="local-video"></video>
      {/* //   ) : (
    //     <video autoPlay className="remote-video" id="remote-video"></video>
    //   )} */}
    </div>
  );
}
