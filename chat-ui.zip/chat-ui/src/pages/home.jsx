import React, { useEffect, useState } from "react";
import socketInstance from "../socketInstance";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const [streams, setStreams] = useState({});
  const socket = socketInstance(localStorage.getItem("token"));

  const navigate = useNavigate();

  const updateRooms = (data) => {
    // console.log(data);
    setStreams(data);
  };

  const onRoomCreated = (room_id) => {
    navigate(`/stream?watch=${room_id}&admin=true`);
  };

  useEffect(() => {
    socket.emit("get:rooms");
    socket.on("rooms:data", updateRooms);
    socket.on("room:update", updateRooms);
    socket.on("room:created", onRoomCreated);

    return () => {
      socket.removeEventListener("rooms:data", updateRooms);
      socket.removeEventListener("rooms:update", updateRooms);
      socket.removeEventListener("rooms:created", onRoomCreated);
    };
  }, []);

  const startStream = () => {
    socket.emit("room:create");
  };

  return (
    <div>
      <h1>Available Streams</h1>
      {Object.keys(streams).map((_item) => (
        <p
          key={_item}
          onClick={() => {
            socket.emit("room:join", _item);
            navigate(`/stream?watch=${_item}`);
          }}
        >
          {_item}
        </p>
      ))}
      <button onClick={startStream}>Start Stream</button>
    </div>
  );
}
