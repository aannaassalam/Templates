type Props = {};

export default function index({}: Props) {
  return <div>index</div>;
}
