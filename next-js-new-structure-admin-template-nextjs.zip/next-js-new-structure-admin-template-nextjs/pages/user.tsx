import DashboardLayout from "@/layout/dashboard/DashboardLayout";
// ----------------------------------------------------------------------

export default function UserPage() {
  return <DashboardLayout>user</DashboardLayout>;
}
