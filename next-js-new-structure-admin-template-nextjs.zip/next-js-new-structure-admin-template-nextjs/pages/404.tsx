import NotFound from "@/components/common/NotFound";

const Index = () => <NotFound />;

export default Index;
