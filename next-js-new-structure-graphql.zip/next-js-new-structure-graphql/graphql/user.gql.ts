import { gql } from "@apollo/client";

export const FETCH_USER_LOGIN = gql`
  query fetchUserDetails(
    $login: String!
    $canReceiveOrganizationEmailsWhenNotificationsRestrictedLogin2: String!
  ) {
    user(login: $login) {
      anyPinnableItems
      avatarUrl
      bio
      bioHTML
      canReceiveOrganizationEmailsWhenNotificationsRestricted(
        login: $canReceiveOrganizationEmailsWhenNotificationsRestrictedLogin2
      )
    }
  }
`;
