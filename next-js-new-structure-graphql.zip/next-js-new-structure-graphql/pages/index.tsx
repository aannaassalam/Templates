import Wrapper from "@/layout/wrapper/Wrapper";
import CustomButtonPrimary from "@/ui/CustomButtons/CustomButtonPrimary";
import { useLazyQuery } from "@apollo/client";
import { Container, Grid, Paper, TextField } from "@mui/material";
import { FETCH_USER_LOGIN } from "graphql/user.gql";
import { useState } from "react";

export default function Home() {
  const [getDetails, { loading, error, data }] = useLazyQuery(FETCH_USER_LOGIN);
  const [user, setUser] = useState("");

  return (
    <Wrapper>
      <Container>
        <Grid container>
          <Grid mt={2} item xs={12}>
            <Paper
              sx={{
                padding: "20px"
              }}
            >
              <TextField
                value={user}
                onChange={(e) => setUser(e.target.value)}
                label="Username"
                variant="outlined"
              />
              <CustomButtonPrimary
                onClick={() => {
                  getDetails({
                    variables: {}
                  });
                }}
                variant="outlined"
              >
                Submit
              </CustomButtonPrimary>
            </Paper>
          </Grid>

          <Grid mt={2} item xs={12}>
            <Paper
              sx={{
                padding: "20px"
              }}
            >
              {JSON.stringify(data)}
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Wrapper>
  );
}
