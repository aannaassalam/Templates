import styled from "@emotion/styled";
import Box from "@mui/material/Box";

export const StoryWrapper = styled(Box)``;

export const StoryCardWrapper = styled(Box)``;
