export interface CustomIconProps {
  IconColor?: string;
  IconWidth?: string;
  IconHeight?: string;
}
