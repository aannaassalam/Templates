import styled from "@emotion/styled";
import { Box } from "@mui/material";

export const WeoffersWrapper = styled(Box)`
    
`